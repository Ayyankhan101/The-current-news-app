'use client';

import { useState, useEffect } from 'react';

interface NewsSource {
  id: string;
  name: string;
}

interface NavbarProps {
  searchTerm: string;
  selectedSource: string;
  onSearchChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onFilterButtonClick: (e: React.MouseEvent<HTMLButtonElement>) => void;
  onFilterOptionClick: (source: string) => void;
  isFilterDropdownOpen: boolean;
  sources: NewsSource[];
  getSourceCount: (source: string) => number;
}

const Navbar: React.FC<NavbarProps> = ({
  searchTerm,
  selectedSource,
  onSearchChange,
  onFilterButtonClick,
  onFilterOptionClick,
  isFilterDropdownOpen,
  sources,
  getSourceCount,
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileSearchVisible, setIsMobileSearchVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMobileSearch = () => {
    setIsMobileSearchVisible(!isMobileSearchVisible);
  };

  return (
    <nav className={`nav ${isScrolled ? 'scrolled' : ''}`}>
      <div className="nav-container">
        <a href="#" className="logo">The Current</a>
        <ul className="nav-links">
          <li><a href="#home">Home</a></li>
          <li><a href="#news">News</a></li>
          <li><a href="#tech">Technology</a></li>
          <li><a href="#business">Business</a></li>
          <li><a href="#contact">Contact</a></li>
        </ul>
        <div className={`search-container ${isMobileSearchVisible ? 'mobile-show' : ''}`}>
          <div className="search-wrapper">
            <span className="search-icon">🔍</span>
            <input
              type="text"
              className="search-input"
              placeholder="Search news..."
              value={searchTerm}
              onChange={onSearchChange}
            />
          </div>
          <div style={{ position: 'relative' }}>
            <button className={`filter-button ${isFilterDropdownOpen ? 'active' : ''}`} id="filterButton" onClick={onFilterButtonClick}>
              <span>{selectedSource === 'all' ? 'All Sources' : sources.find(s => s.id === selectedSource)?.name || 'All Sources'}</span>
              <span style={{ fontSize: '12px' }}>▼</span>
            </button>
            <div className={`filter-dropdown ${isFilterDropdownOpen ? 'show' : ''}`} id="filterDropdown">
              <div className={`filter-option ${selectedSource === 'all' ? 'selected' : ''}`} data-source="all" onClick={() => onFilterOptionClick('all')}>
                <span>All Sources</span>
                <span className="filter-count">{getSourceCount('all')}</span>
              </div>
              {sources.map(source => (
                <div
                  key={source.id}
                  className={`filter-option ${selectedSource === source.id ? 'selected' : ''}`}
                  data-source={source.id}
                  onClick={() => onFilterOptionClick(source.id)}
                >
                  <span>{source.name}</span>
                  <span className="filter-count">{getSourceCount(source.id)}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
        <button className="mobile-search-toggle" id="mobileSearchToggle" onClick={toggleMobileSearch}>🔍</button>
      </div>
    </nav>
  );
};

export default Navbar;