const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer-content">
        <div className="footer-links">
          <a href="#">Privacy Policy</a>
          <a href="#">Terms of Service</a>
          <a href="#">About Us</a>
          <a href="#">Contact</a>
          <a href="#">Careers</a>
        </div>
        <p className="footer-text">© 2025 Nexus News. All rights reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;