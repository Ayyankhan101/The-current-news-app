'use client';

import { useState, useEffect, useCallback } from 'react';
import './globals.css';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import React from 'react';
import NewsContext from '../context/NewsContext';

interface Article {
  source: { id: string; name: string };
  author: string;
  title: string;
  description: string;
  url: string;
  urlToImage: string;
  publishedAt: string;
  content: string;
}

interface NewsSource {
  id: string;
  name: string;
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const [articles, setArticles] = useState<Article[]>([]);
  const [filteredArticles, setFilteredArticles] = useState<Article[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [debouncedSearchTerm, setDebouncedSearchTerm] = useState('');
  const [selectedSource, setSelectedSource] = useState('all');
  const [isFilterDropdownOpen, setIsFilterDropdownOpen] = useState(false);
  const [sources, setSources] = useState<NewsSource[]>([]);

  useEffect(() => {
    document.title = 'The Current';
  }, []);

  // Debounce search term
  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedSearchTerm(searchTerm);
    }, 500); // 500ms debounce

    return () => {
      clearTimeout(handler);
    };
  }, [searchTerm]);

  const fetchArticles = useCallback(async () => {
    const queryParam = debouncedSearchTerm ? `q=${debouncedSearchTerm}` : 'q=latest';
    const sourceParam = selectedSource !== 'all' ? `&source=${selectedSource}` : '';
    const apiUrl = `/api/search?${queryParam}${sourceParam}`;
    console.log('Fetching articles from:', apiUrl);
    const response = await fetch(apiUrl);
    const data = await response.json();
    console.log('API response:', data);
    setArticles(data.articles || []);
    setFilteredArticles(data.articles || []);
  }, [debouncedSearchTerm, selectedSource]);

  const fetchSources = useCallback(async () => {
    const apiUrl = `/api/sources`;
    console.log('Fetching sources from:', apiUrl);
    const response = await fetch(apiUrl);
    const data = await response.json();
    console.log('Sources API response:', data);
    setSources(data.sources || []);
  }, []);

  useEffect(() => {
    fetchArticles();
  }, [fetchArticles]);

  useEffect(() => {
    fetchSources();
  }, [fetchSources]);

  const handleSearchInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };

  const handleFilterButtonClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.stopPropagation();
    setIsFilterDropdownOpen(prev => !prev);
  };

  const handleFilterOptionClick = (source: string) => {
    setSelectedSource(source);
    setIsFilterDropdownOpen(false);
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const filterButton = document.getElementById('filterButton');
      const filterDropdown = document.getElementById('filterDropdown');
      if (filterButton && filterDropdown && !filterButton.contains(event.target as Node) && !filterDropdown.contains(event.target as Node)) {
        setIsFilterDropdownOpen(false);
      }
    };

    document.addEventListener('click', handleClickOutside);
    return () => {
      document.removeEventListener('click', handleClickOutside);
    };
  }, []);

  const getSourceCount = (sourceId: string) => {
    if (sourceId === 'all') return articles.length;
    return articles.filter(article => article.source.id === sourceId).length;
  };

  return (
    <html lang="en">
      <body>
        <NewsContext.Provider value={{ filteredArticles }}>
          <Navbar
            searchTerm={searchTerm}
            selectedSource={selectedSource}
            onSearchChange={handleSearchInputChange}
            onFilterButtonClick={handleFilterButtonClick}
            onFilterOptionClick={handleFilterOptionClick}
            isFilterDropdownOpen={isFilterDropdownOpen}
            sources={sources}
            getSourceCount={getSourceCount}
          />
          {children}
          <Footer />
        </NewsContext.Provider>
      </body>
    </html>
  );
}