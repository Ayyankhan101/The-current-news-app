import { NextResponse } from 'next/server';

export async function GET() {
  try {
    const NEWS_API_KEY = process.env.NEWS_API_KEY;
    if (!NEWS_API_KEY) {
      throw new Error('NEWS_API_KEY is not defined in environment variables.');
    }

    const url = `https://newsapi.org/v2/sources?apiKey=${NEWS_API_KEY}`;
    console.log('Fetching sources from NewsAPI URL:', url);
    const response = await fetch(url);

    if (!response.ok) {
      const errorData = await response.json();
      console.error('Error response from NewsAPI (sources):', errorData);
      return NextResponse.json({ error: 'Failed to fetch news sources from external API', details: errorData }, { status: response.status });
    }

    const data = await response.json();
    console.log('NewsAPI sources response data:', data);
    return NextResponse.json(data);
  } catch (error: any) {
    console.error('Error fetching news sources:', error.message, error.stack);
    return NextResponse.json({ error: 'Failed to fetch news sources', details: error.message }, { status: 500 });
  }
}
