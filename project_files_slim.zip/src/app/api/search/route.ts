import { NextRequest, NextResponse } from 'next/server';

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const query = searchParams.get('q') || 'latest';
  const source = searchParams.get('source') || '';

  console.log('API request received:', { query, source });

  try {
    const NEWS_API_KEY = process.env.NEWS_API_KEY;
    if (!NEWS_API_KEY) {
      throw new Error('NEWS_API_KEY is not defined in environment variables.');
    }

    const url = `https://newsapi.org/v2/everything?q=${query}&sources=${source}&language=en&sortBy=publishedAt&page=1&pageSize=20&apiKey=${NEWS_API_KEY}`;
    
    console.log('Fetching from NewsAPI URL:', url);
    const response = await fetch(url);
    
    if (!response.ok) {
      const errorData = await response.json();
      console.error('Error response from NewsAPI:', errorData);
      return NextResponse.json({ error: 'Failed to fetch news from external API', details: errorData }, { status: response.status });
    }

    const data = await response.json();
    console.log('NewsAPI response data:', data);
    return NextResponse.json(data);
  } catch (error: any) {
    console.error('Error fetching news:', error.message, error.stack);
    return NextResponse.json({ error: 'Failed to fetch news', details: error.message }, { status: 500 });
  }
}