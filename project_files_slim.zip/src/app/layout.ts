export const metadata = {
  title: 'The Current',
  description: 'The future of news, delivered with precision and style.',
};
