'use client';

import React from 'react';
import { useNews } from '../context/NewsContext';

interface Article {
  source: { id: string; name: string };
  author: string;
  title: string;
  description: string;
  url: string;
  urlToImage: string;
  publishedAt: string;
  content: string;
}

const Home: React.FC = () => {
  const { filteredArticles } = useNews();

  return (
    <>
      {/* Hero Section */}
      <section className="hero">
        <div className="hero-bg"></div>
        <div className="hero-content">
          <h1 className="hero-title">Stay Informed</h1>
          <p className="hero-subtitle">The future of news, delivered with precision and style.</p>
        </div>
      </section>

      {/* Main Content */}
      <main className="main-content">
        <h2 className="section-title">Latest Stories</h2>

        {/* News Grid */}
        <div className="news-grid">
          {filteredArticles.length > 0 ? (
            filteredArticles.map((article, index) => (
              <article
                key={index}
                className="news-card"
                onMouseEnter={(e) => (e.currentTarget.style.transform = 'translateY(-10px) scale(1.02)')}
                onMouseLeave={(e) => (e.currentTarget.style.transform = 'translateY(0) scale(1)')}
              >
                <div className="news-image" style={{ backgroundImage: `url(${article.urlToImage || '/placeholder-image.jpg'})`, backgroundSize: 'cover', backgroundPosition: 'center' }}></div>
                <div className="news-content">
                  <div className="news-category">{article.source.name}</div>
                  <h3 className="news-title">{article.title}</h3>
                  <p className="news-excerpt">{article.description}</p>
                  <div className="news-meta">
                    <span>{new Date(article.publishedAt).toLocaleDateString()}</span>
                    <a href={article.url} target="_blank" rel="noopener noreferrer" className="read-more">Read More</a>
                  </div>
                </div>
              </article>
            ))
          ) : (
            <p>No articles found.</p>
          )}
        </div>

        {/* Featured Section */}
        <section className="featured">
          <div className="featured-content">
            <h2 className="featured-title">Never Miss a Story</h2>
            <p className="featured-text">Subscribe to our newsletter and get the latest news delivered directly to your unpopular inbox with our signature clean design.</p>
            <button
              className="cta-button"
              onClick={(e) => {
                e.preventDefault();
                (e.currentTarget as HTMLElement).style.transform = 'scale(0.95)';
                setTimeout(() => {
                  (e.currentTarget as HTMLElement).style.transform = 'scale(1)';
                }, 150);
              }}
            >Subscribe Now</button>
          </div>
        </section>
      </main>
    </>
  );
};

export default Home;